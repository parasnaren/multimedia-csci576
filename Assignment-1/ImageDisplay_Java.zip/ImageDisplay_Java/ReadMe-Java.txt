A sample program to display and manipulate two images in left and right.
The program creates a plain white RGB image (resolution: 512x512) with black line drawn on it.


Unzip the folder to where you want.
To run the code from command line, first compile with:

>> javac ImageDisplay.java

and then, you can run it to take in one parameters "n":

>> java ImageDisplay n

where the parameter "n" is a "dummy" parameter used to give an additional example of command line args in Java.